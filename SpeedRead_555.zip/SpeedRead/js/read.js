var interval;

function getXmlDoc(cont){
	document.getElementById("auth").innerHTML = "";
	var myText = cont;
/*	alert(text.children[0]); */
	parser = new DOMParser();
    xmlDoc = parser.parseFromString(myText,"text/xml");
    
    return xmlDoc;        
}

function getAuth(text) {
	var cont = text;https://www.google.ru/search?client=ubuntu&channel=fs&q=gist&ie=utf-8&oe=utf-8&gfe_rd=cr&ei=CM54WZijGoHEtAHY1ZToAg
	var xmlDoc = getXmlDoc(cont);
	$(xmlDoc).find("title-info").find("author").each(function () {
		$("#auth").append($(this).find("first-name").text() + "" + $(this).find("last-name").text() + ": ");
	});
	
	$(xmlDoc).find("title-info").each(function () {
		$("#auth").append("<b>" + $(this).find("book-title").text() + "</b>");
	});
}

var indexP = 0;
var indexInP = 0;
var index = 0;
var sizeP = 0;

function printOneWord(arrOfPar,numPar){
	console.log(indexP + '=>' + numPar);
	if (indexP < numPar) { // если параграфы не закончились, то выводим текущее слово нужного
		var parCont = arrOfPar[indexP]; // текст в параграфе
		var arrWordsInP = parCont.split(" "); // массив слов в параграфе
		sizeP = numPar;
		if(indexInP < arrWordsInP.length) { // если пробежались не по всем словам, то выводим следующее
			document.getElementById("box").innerHTML = arrWordsInP[indexInP];
			indexInP++;
		}
		else { // иначе переходим к следующему параграфу
			indexP++;
			indexInP = 0;
		}
	}
	else { // чистим интервал
		clearInterval(interval);
	}
} 

function getText(text) {
	var cont = text;
	var xmlDoc = getXmlDoc(cont);
	
	var arrOfPar = [];
	
	document.getElementById("book_cont").hidden = false;
	
	$(xmlDoc).find("section").find("p").each(function () {
		$("#book_cont").append($(this).text()+"<br>&nbsp &nbsp &nbsp");
		
		/* var arrWords = [];
		
		var str = $(this).text();
		arrWords = str.split(" ");
			
		var lenArrW = arrWords.length;
		indexInP = 0; */
		
		arrOfPar[arrOfPar.length] = $(this).text(); //массив параграфов

		//занести indexInP
	});
	
	//////////////////////из ЛОКАОСТОРАДЖ или сделать кнопку сначала + по нажатию на span его id в ЛОКАЛСТОРАДЖ
	
	var path = localStorage.getItem("curent");
	var indexWord = localStorage.getItem(path).split("_"); // установили там, где остановились
	
	indexP = indexWord[0];	
	indexInP = indexWord[1];
	sizeP = indexWord[2];
	
	var numPar = arrOfPar.length;
	
	var slider = document.getElementById("slider-fill").value;
	var record = localStorage.getItem("record");
	
	if (slider > record) { // если побит рекорд, то изменяем
		localStorage.setItem("record",slider);
		// document.getElementById("record").innerHTML = "My max speed: " + record;
	}
	
	// alert(slider);
	
	var speed =((100-slider)*15 + 1);
	
	interval = setInterval(printOneWord,speed,arrOfPar,numPar);
/*	clearInterval(interval);
*/}

function pauseReading() {
	// alert(indexP + ' ' + indexInP);
	clearInterval(interval);
	
	var savingBook = localStorage.getItem("curent"); // сохраним индекс абзаца в текущей книге
	var indexWord = [indexP,indexInP,sizeP].join("_");
	localStorage.setItem(savingBook,indexWord);
	
	document.getElementById("read_book").disabled = false;
	$( "#slider-fill" ).slider({
		  disabled: false
		});
}

function isInLocalstorage(path) {
	var names = [];

	// alert('len = ' + localStorage.length);

	for(i = 0; i < localStorage.length; i++)
	{
		names[i] = localStorage.key(i);
	// alert(names[i]+"__________"+values[i]);
	}
	
	if ((names.indexOf(path))===-1) {
		return false;
	}
	else {
		return true;
	}
}

var flagIn = 0;
var newName = '';

function readBookFile(){ // здесь и проверяем есть ли книга в локалсторадже
	
	tizen.power.request('CPU', 'CPU_AWAKE');
	tizen.power.request('SCREEN', 'SCREEN_NORMAL');
	tizen.power.turnScreenOn();
	
	var path = localStorage.getItem("curent");
	// alert(path);
	
	if (isInLocalstorage(path)===true) { // если книга встртилась в localstorage, то увеличим flag
	   	flagIn = 33;
	   	newName = path;
    }
	else { // иначе в локалсторадж
		localStorage.setItem(path,"0_0_0");
	//	alert('load to localstorage');
	}	
		
	document.getElementById("read_book").disabled = true;
	
	$( "#slider-fill" ).slider({
		  disabled: true
		});
	
	tizen.filesystem.resolve("documents", function(dir) 
	    {
	       file = dir.resolve(path);
	       file.openStream(
	    	    "r", 
			    function(fs) {
	                var text = fs.read(file.fileSize);
	                fs.close();
	                //console.log(text);

                    getText(text);
	            	getAuth(text);
	            	/*myXml(text);*/
	            }, function(e) {
	                console.log("Error " + e.message);
	                book = document.getElementById("book_err");
	            	book.innerHTML = e.message;
	            }, "UTF-8");
	    });
	console.log("OK BOOK");
	document.getElementById("read_book").disabled = true; //////////////ПОСТАВИТЬ СЧЕТЧИК КНИГИ ВНАЧАЛО//////////////
}

function clearCont() {
	pauseReading();
	
	indexP = 0;
	indexInP = 0;
	
	document.getElementById("auth").innerHTML = "";
	document.getElementById("book_cont").innerHTML = "";
	document.getElementById("box").innerHTML = "WORD";
	// document.getElementById("back").click();
	
	newUrl();
}

function reset() {
	pauseReading();
	
	var path = localStorage.getItem("curent");
	localStorage.setItem(path,"0_0_0"); 
	
	indexP = 0;
	
	document.getElementById("auth").innerHTML = "";
	document.getElementById("book_cont").innerHTML = "";
	document.getElementById("box").innerHTML = "WORD";
}

function newUrl() {
    window.location.assign("index.html");
}

//24/7 23:16
/*function writeTestFile(){
	var newDir, newFile;
	tizen.filesystem.resolve("documents", function(dir) 
	    {
	       newDir = dir.createDirectory("newDir");
	       newFile = newDir.createFile("newFilePath.txt");
	       newFile.openStream(
	        "w",
	        function(fs) {
	        	 fs.write("test test test");
	        	 fs.close();
	        }, function(e) {
	        	 console.log("Error " + e.message);
	        }, "UTF-8");
	    });
	console.log("OK W");
}*/
    
/*function readTestFile(){
	tizen.filesystem.resolve("documents", function(dir) 
	    {
	       file = dir.resolve("newDir/newFilePath.txt");
	       file.openStream(
	    	    "r", 
			    function(fs) {
	                var text = fs.read(file.fileSize);
	                fs.close();
	                console.log(text);
	            }, function(e) {
	                console.log("Error " + e.message);
	            }, "UTF-8");
	    });
	console.log("OK R");
}*/
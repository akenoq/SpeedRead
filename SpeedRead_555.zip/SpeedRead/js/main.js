//Initialize function
var init = function () {
	// TODO:: Do your initialization job
	console.log("init() called");
	
	// add eventListener for tizenhwkey

	var arr = window.location.href.split('/');
	var url = arr[arr.length-1];
	
	if (url === "index.html") {
		loadLib();
	}
	
	document.addEventListener('tizenhwkey', function(e) {
		if(e.keyName === "back") {
						
			var arr = window.location.href.split('/');
			var url = arr[arr.length-1];
			
			// alert(window.location.href);

			// alert(url);
			
			if (url === "index.html") {
			try {	
				tizen.application.getCurrentApplication().exit();
			} 
			catch (error) {
				console.error("getCurrentApplication(): " + error.message);
			}
			}
			else {
				var arr = window.location.href.split('/');
				var url = arr[arr.length-1];
				
				// alert(window.location.href);

				// alert(url);
				
				if (url === "read.html") {
					clearCont();
				}
				else {
					history.back();
				}
			}
		}
		
		/*if(e.keyName === "menu") {
			
			var arr = window.location.href.split('/');
			var url = arr[arr.length-1];
			
			// alert(window.location.href);

			// alert(url);
			
			if (url === "index.html") */
	});
	
};

window.onload = init();

function loadXmlDoc(cont){ ////////////////////НАЗВАНИЕ ФУНКЦИЙ//////////////////

	var myText = cont;
/* alert(text.children[0]); */
	parser = new DOMParser();
    xmlDoc = parser.parseFromString(myText,"text/xml");
    
    return xmlDoc;        
}

function loadAuth(text,i) {
	var cont = text;
	var xmlDoc = loadXmlDoc(cont);
	
	var auth_id = ['auth',i.toString()].join('_'); // получаем id div с автором
	
	$(xmlDoc).find("title-info").find("author").each(function () {
		document.getElementById(auth_id).innerHTML = "<i>" + $(this).find("first-name").text() + ' ' + $(this).find("last-name").text() + "</i>";
	});
}

function loadName(text,i) {
	var cont = text;
	var xmlDoc = loadXmlDoc(cont);

	var bookname_id = ['bookname',i.toString()].join('_'); // получаем id div с названием книги

	$(xmlDoc).find("title-info").each(function () {
		document.getElementById(bookname_id).innerHTML = "<b>" + $(this).find("book-title").text() + "</b>"; 
	
	// В ЛОКАЛСТОРАДЖ ИМЯ или ИМЯ ФАЙЛА
		
	});	
}

function loadTitleAndAuth(path,i) {
	var proc_id = ['proc',i.toString()].join('_');
	alert(path);
	
	try {
		var indexWord = localStorage.getItem(path).split("_"); // установили там, где остановились
	
		var indP = indexWord[0];	
		var indInP = indexWord[1];
		var allP = indexWord[2];

		document.getElementById(proc_id).innerHTML = 'Progress: '(100*indP/allP).toString()+'%';
	}
	catch (e) {
		// document.getElementById(proc_id).innerHTML = 'Progress: 0%';
	}
	
	tizen.filesystem.resolve("documents", function(dir) 
		    {
		       file = dir.resolve(path);
		       file.openStream(
		    	    "r", 
				    function(fs) {
		                var text = fs.read(file.fileSize);
		                fs.close();
	//	                console.log(text);
		            	loadAuth(text,i);
		            	loadName(text,i);
		            	/*myXml(text);*/
		            }, function(e) {
		                console.log("Error " + e.message);
		                book = document.getElementById("book_err");
		            	book.innerHTML = e.message;
		            }, "UTF-8");
		    });
		console.log("OK BOOK");
}

function setCurentBookAndRead(path) {
	localStorage.setItem("curent",path);
	document.getElementById("read").click();
}

function isRecord() {
	var names = [];

	for(i = 0; i < localStorage.length; i++)
	{
		names[i] = localStorage.key(i);
	}
	
	if ((names.indexOf("record"))===-1) {
		return false;
	}
	else {
		return true;
	}
}

function loadLib() {
	
	if (!isRecord()) { // если рекора нет, то создаем
		localStorage.setItem("record",0); //
	}

	document.getElementById("record").innerHTML = "My max speed: " + localStorage.getItem("record");
	
	var documentsDir;
	var dir = tizen.filesystem;
		
	function onsuccess(files) {
		if (files.length===0) { alert("You library is empty. Please, load books!") }
		
		document.getElementById("lib_cont").innerHTML = "";
		
		for(var i = 0; i < files.length; i++) {
		     console.log("File Name is " + files[i].name); // displays file name
		     var format = files[i].name.split(".");
		     if (format[1]==="fb2"){
		     var str = document.getElementById("lib_cont").innerHTML;
		     
		     // auth_id и bookname_id
		    /*document.getElementById("lib_cont").innerHTML = str + '<div data-role="content book"><div id="auth_'+i+'"></div>' +
			'<div id="bookname_'+i+'"></div></div><button class="ui-btn" style="margin-left: 18px; width: 290px;"onclick="localStorage.setItem("curent","'+files[i].name+'"); alert(localStorage.getItem("curent")); document.getElementById("read").click();">READ!</button>';*/
		     
		     var filename = "'"+files[i].name+"'";		     
		     document.getElementById("lib_cont").innerHTML = str + '<div data-role="content" class="book"><div id="auth_'+i+'"></div>' + 
		     '<div id="bookname_'+i+'"></div><div class="proc" id="proc_'+i+'></div></div><button class="ui-btn" onclick="setCurentBookAndRead('+filename+')" style="border-radius: 5px;">READ!</button>';		 
		     
		     
		     //alert(files[i].name);
		     
		     
		  /*  document.getElementById("lib_cont").innerHTML = str + '<div class="ui-content book"><div id="auth_'+i+'"></div>' +
				'<div id="bookname_'+i+'"></div></div>';*/
		     
		     //////////////В ЛОКАЛСТОРАДЖ ТЕКУЩУЮ КНИГУ//////////////////////////
		     
		     // document.getElementById("list_of_files").innerHTML = str + files[i].name + '; ';
		     loadTitleAndAuth(files[i].name,i);
		     }
		   }

		   console.log("после вывода списка файлов");

		   //var str = document.getElementById("list_of_files").innerHTML;
		   // document.getElementById("list_of_files").innerHTML = str + '<br>';
		   
		   console.log("перенос строки после вывода списка файлов");
		   //alert(localStorage.getItem("curent"));
	}	   
	
	function onerror(error) {
		console.log("The error " + error.message + " occurred when listing the files in the selected folder");
	}

		tizen.filesystem.resolve(
			     'documents',
			     function(dir){
			       documentsDir = dir; 
			       dir.listFiles(onsuccess,onerror);
			     }, function(e) {
			       console.log("Error" + e.message);
			     }, "rw"
			 );
}

function resetAll() {
	localStorage.clear();
	alert('Reset results success');
	loadLib();
}

function goLoad() {
	window.location.assign("load.html");
}
